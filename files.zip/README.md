# renzstudiocreatives — Creative Designer Portfolio

A single-page portfolio website for **Renz**, a creative designer, church photographer, video editor and social media manager. It is one self-contained `index.html` file with no build step, frameworks or external dependencies other than the Google Font.

## Sections

| Section | What it shows |
| --- | --- |
| **Hero** | Name, title, portrait and quick-glance services |
| **Marquee** | Organizations worked with and tools used (CHM Hub, RIOT History Maker Hub, Canva, CapCut, Meta Business Suite) |
| **Quote** | Scroll-reveal quote that lights up word by word |
| **About** | Short bio with animated counters (years of experience, followers, featured designs) |
| **Creative journey** | Timeline of roles |
| **Services** | Graphic design, video editing, social media management, church photography |
| **My graphic design** | Two auto-scrolling rows of designs. Hover to pause, click to enlarge |
| **Photography** | Draggable photo gallery with parallax, tilt on hover and click-to-enlarge |
| **Video editing** | Short-form videos that autoplay when scrolled into view, plus a YouTube link |
| **Pages I manage** | Phone mockups of the Facebook pages managed, with a "hand reaching in" animation |
| **Contact** | Email link and social links |

## Features

- Dark theme with an orange/red accent, using CSS variables
- Scroll progress bar and a cursor-following glow
- Scroll-reveal animations and animated number counters
- 3D tilt effect on cards
- Draggable photo gallery with:
  - mouse drag and touch swipe
  - slow auto-drift that pauses on hover or touch
  - parallax inside each photo
  - progress indicator
- Lightbox viewer for designs and photos (press `Esc` or click to close)
- Responsive layout for desktop, tablet and phone
- Respects `prefers-reduced-motion`

## Project structure

```
renz-portfolio/
├── index.html   # page markup (images and videos are embedded here)
├── style.css    # all styles
├── script.js    # all interactions and animations
└── README.md
```

Keep all four files in the same folder so `index.html` can find `style.css` and `script.js`. Images and videos are embedded in `index.html` as base64 data, so that file is large (about 9 MB).

## Run locally

No install needed. Open `index.html` in any modern browser.

To serve it locally instead:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploy

Because it is a static file, it works on any static host:

- **GitHub Pages:** push `index.html` to a repo, then enable Pages in the repo settings
- **Netlify / Vercel:** drag and drop the folder, or connect the repo
- **Cloudflare Pages:** connect the repo or upload the folder

To use a custom domain (for example `renzstudiocreatives.com`), add it in your host's domain settings.

## Customize

### Add or change gallery photos

Inside the `Photography` section, each photo is one `<figure class="pc2">`:

```html
<figure class="pc2" style="--ar:1.52">
  <img src="photo.jpg" alt="Description" draggable="false" loading="lazy">
  <figcaption><small>01</small><b>Title</b><span>Caption</span></figcaption>
</figure>
```

- `--ar` is the photo's **width ÷ height** (for example `1.5` for landscape, `0.67` for portrait).
- Use a file path (`photo.jpg`) or a base64 data URI for `src`.
- Add or remove `<figure>` blocks freely. The progress bar and parallax adjust automatically.

### Change colors

Edit the CSS variables at the top of `style.css`:

```css
:root{--bg:#0c0c0e;--panel:#141416;--or:#ff5a1f;--or2:#ff8a3d;--red:#c9301a;--text:#f5f2ee;--mute:#9b9690}
```

### Change text and links

Search `index.html` for the text you want to change (bio, roles, services, follower counts, email, YouTube link) and edit it directly.

### Add videos

Replace the `<video src="...">` inside the `Video editing` section with a file path or data URI. Videos autoplay muted when scrolled into view and pause when they leave the screen.

## Tech

- HTML5, CSS3 (grid, flexbox, custom properties, container queries)
- Vanilla JavaScript (IntersectionObserver, Pointer Events, requestAnimationFrame)
- Google Fonts: Plus Jakarta Sans

## Browser support

Current versions of Chrome, Edge, Safari and Firefox, on desktop and mobile.

## Credits

Designed and built for **renzstudiocreatives**. Photography by the CHM Valenzuela multimedia team. Page built with the help of Claude.
