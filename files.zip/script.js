/* renzstudiocreatives — site scripts (extracted from index.html)
   Loaded by index.html with: <script src="script.js" defer></script>
   Part 1: scroll effects, counters, tilt, timeline, phone mockups, lightbox, scrolling rows
   Part 2: draggable photography gallery */

/* ---- Part 1 ---- */
(function(){
var bar=document.getElementById('bar'),ph=document.getElementById('ph'),q=document.getElementById('q'),gl=document.getElementById('glow');
var ks=(q.dataset.k||'').split(',');
q.innerHTML=q.textContent.split(' ').map(function(w){var k=ks.indexOf(w.replace(/[^a-z.]/gi,'').toLowerCase())>-1;return '<span'+(k?' class="k"':'')+'>'+w+'</span>'}).join(' ');
var qs=q.querySelectorAll('span');
var D=['Birthday greeting','Sunday service','Caroling contest','Volunteer with us','Faith series','Will you… come to church','God Himself will','God can turn it for your good','God is with you through it all','Destroy the false altar'],wk=document.getElementById('wk');
D.forEach(function(n){var d=document.createElement('div');d.className='w rv';d.textContent=n;wk.appendChild(d)});
var tr=document.getElementById('tr');tr.innerHTML+=tr.innerHTML;
function sc(){var h=document.documentElement.scrollHeight-innerHeight,y=scrollY;bar.style.width=(y/h*100)+'%';
if(y<innerHeight*1.2)ph.style.transform='translateY('+y*.14+'px) scale('+(1+y/4000)+')';
var r=q.getBoundingClientRect(),pr=Math.min(1,Math.max(0,(innerHeight*.85-r.top)/(innerHeight*.6+r.height)));
var on=Math.round(pr*qs.length);qs.forEach(function(s,i){s.classList.toggle('on',i<on)});
document.querySelectorAll('.w').forEach(function(w,i){if(i%5==0){var b=w.getBoundingClientRect();w.style.setProperty('--p',((b.top-innerHeight/2)*.08)+'px')}})}
addEventListener('scroll',sc,{passive:true});sc();
addEventListener('mousemove',function(e){gl.style.left=e.clientX+'px';gl.style.top=e.clientY+'px'});
var io=new IntersectionObserver(function(en){en.forEach(function(e){if(!e.isIntersecting)return;var el=e.target;el.classList.add('in');
if(el.dataset&&el.dataset.n)cnt(el);el.querySelectorAll&&el.querySelectorAll('[data-n]').forEach(cnt);io.unobserve(el)})},{threshold:.15});
document.querySelectorAll('.rv,.step').forEach(function(el,i){el.style.transitionDelay=(i%4)*90+'ms';io.observe(el)});
function cnt(el){if(el.done)return;el.done=1;var n=+el.dataset.n,v=0,st=Math.max(1,Math.ceil(n/50)),s=el.dataset.s||'';var iv=setInterval(function(){v=Math.min(n,v+st);el.textContent=v+s;if(v>=n)clearInterval(iv)},30)}
document.querySelectorAll('.card,.stat').forEach(function(el){el.addEventListener('mousemove',function(e){var r=el.getBoundingClientRect();el.style.transform='perspective(700px) rotateY('+((e.clientX-r.left)/r.width-.5)*7+'deg) rotateX('+(-((e.clientY-r.top)/r.height-.5))*7+'deg)'});el.addEventListener('mouseleave',function(){el.style.transform=''})});
document.querySelectorAll('.vids video').forEach(function(v){new IntersectionObserver(function(e){if(e[0].isIntersecting){v.play().catch(function(){})}else{v.pause()}},{threshold:.5}).observe(v)});
})();
(function(){var t=document.getElementById('ptl');if(!t)return;var cols=t.querySelectorAll('.pcol'),fill=t.querySelector('.fill');function go(i){cols.forEach(function(c,k){c.classList.toggle('on',k===i);c.classList.toggle('reached',k<=i)});fill.style.width=(i/3*100)+'%'}t.addEventListener('click',function(e){var c=e.target.closest('.pcol');if(c)go(+c.dataset.i)});go(0)})();
(function(){var io=new IntersectionObserver(function(en){en.forEach(function(e){if(e.intersectionRatio>=.6)e.target.classList.add('go');else if(e.intersectionRatio<.12)e.target.classList.remove('go')})},{threshold:[0,.12,.6,.9]});document.querySelectorAll('.ph').forEach(function(p){io.observe(p);p.addEventListener('click',function(){p.classList.remove('go');setTimeout(function(){p.classList.add('go')},80)})})})();
(function(){var lb=document.getElementById('lb'),li=lb.querySelector('img');function cl(){lb.classList.remove('on')}document.querySelectorAll('.gi').forEach(function(g){g.addEventListener('click',function(){var im=g.querySelector('img');li.src=im.src;li.alt=im.alt;lb.classList.add('on')})});lb.addEventListener('click',cl);addEventListener('keydown',function(e){if(e.key==='Escape')cl()});
document.querySelectorAll('.trk').forEach(function(t){[].slice.call(t.children).forEach(function(c){var k=c.cloneNode(true);k.setAttribute('aria-hidden','true');t.appendChild(k)})});document.querySelectorAll('.trk .gi').forEach(function(g){if(!g.dataset.b){g.dataset.b=1;g.addEventListener('click',function(){var im=g.querySelector('img');li.src=im.src;li.alt=im.alt;lb.classList.add('on')})}});
var an=[].map.call(document.querySelectorAll('.trk'),function(t){return t.getAnimations()[0]}).filter(Boolean),ly=scrollY,v=1;addEventListener('scroll',function(){var d=Math.abs(scrollY-ly);ly=scrollY;v=Math.min(8,Math.max(v,1+d/6))},{passive:true});
(function loop(){v+=(1-v)*.05;an.forEach(function(a){a.updatePlaybackRate(v)});requestAnimationFrame(loop)})()})();

/* ---- Part 2: Photography gallery ---- */
(function(){var t=document.getElementById('pgt'),pi=document.getElementById('pgi'),lb=document.getElementById('lb');if(!t||!lb)return;var li=lb.querySelector('img'),cs=[].slice.call(t.children),down=0,sx=0,sl=0,moved=0,hover=0,dir=1,pos=t.scrollLeft,vis=1,last=0;
function upd(){var m=t.scrollWidth-t.clientWidth,tr=t.getBoundingClientRect(),c=tr.left+tr.width/2;pi.style.width=Math.max(12,t.clientWidth/t.scrollWidth*100)+'%';pi.style.marginLeft=(m>0?t.scrollLeft/m*(100-parseFloat(pi.style.width)):0)+'%';cs.forEach(function(e){var r=e.getBoundingClientRect();e.style.setProperty('--px',(-(r.left+r.width/2-c)/tr.width*34)+'px')})}
t.addEventListener('scroll',upd,{passive:true});addEventListener('resize',upd);
t.addEventListener('pointerdown',function(e){if(e.pointerType==='touch')return;down=1;moved=0;sx=e.clientX;sl=t.scrollLeft});
addEventListener('pointermove',function(e){if(!down)return;var d=e.clientX-sx;if(Math.abs(d)>5){moved=1;t.classList.add('drag')}if(moved){t.scrollLeft=sl-d;pos=t.scrollLeft}});
addEventListener('pointerup',function(){down=0;setTimeout(function(){t.classList.remove('drag')},0)});
t.addEventListener('mouseenter',function(){hover=1});t.addEventListener('mouseleave',function(){hover=0});
t.addEventListener('touchstart',function(){hover=1},{passive:true});t.addEventListener('touchend',function(){setTimeout(function(){hover=0},2500)},{passive:true});
t.addEventListener('wheel',function(e){if(Math.abs(e.deltaX)>Math.abs(e.deltaY)){pos=t.scrollLeft}},{passive:true});
cs.forEach(function(c){c.addEventListener('click',function(){if(moved)return;var im=c.querySelector('img');li.src=im.src;li.alt=im.alt;lb.classList.add('on')});
c.addEventListener('mousemove',function(e){var r=c.getBoundingClientRect();c.style.setProperty('--r',(((e.clientX-r.left)/r.width-.5)*4)+'deg')});c.addEventListener('mouseleave',function(){c.style.removeProperty('--r')})});
new IntersectionObserver(function(e){vis=e[0].isIntersecting}).observe(t);
var rm=matchMedia('(prefers-reduced-motion:reduce)').matches;
(function loop(ts){requestAnimationFrame(loop);if(rm||!vis||hover||down)return;var m=t.scrollWidth-t.clientWidth;if(m<=0)return;if(Math.abs(pos-t.scrollLeft)>2)pos=t.scrollLeft;pos+=dir*.45;if(pos>=m){pos=m;dir=-1}else if(pos<=0){pos=0;dir=1}t.scrollLeft=pos})();upd()})();
